

FLUSH PRIVILEGES;
ALTER USER "root"@"localhost" IDENTIFIED BY "password";
Create database my_database;
Use my_database;

Create table Users
(
    username varchar(20) not null unique,
    pass varchar(20) not null unique,
    email text not null,
    Primary Key(username)
);

Insert into Users values
    ("Matar", "12345", "matar@aucegypt.edu"),
    ("Qaffash", "54321", "youssef@aucegypt.edu")
    ;
        
Create table Events
(
    id int AUTO_INCREMENT,
    E_name varchar(100) not null,
    E_date varchar(50) not null,
    E_time varchar(20) not null,
    Primary Key(id)
);

Insert into Events values
    (null, "Dining with an Aucian", "5/5/2023","8:00 pm"),
    (null, "Happy hour", "5/3/2023","1:00 am"),
    (null, "Christmas Celebration", "23/5/2023","9:00 pm"),
    (null, "Hot Chocolate Gathering", "27/12/2023","8:00 pm"),
    (null, "Music Concert", "30/1/2023","7:00 pm")
    ;

Create table MovShows
(
    id int AUTO_INCREMENT,
    MovShows_name varchar(100) not null,
    MovShows_type varchar(50) not null,
    MovShows_mood varchar(20) not null,
    Primary Key(id)
);

Insert into MovShows values
    (null, "Toy Story", "Movie","Happy"),
    (null, "Rush Hour", "Movie","Happy"),
    (null, "Space Jam", "Movie","Happy"),
    (null, "The Lion King", "Movie","Happy"),
    (null, "The Incredibles", "Movie","Happy"),
    (null, "The Good Dinosaur", "Movie","Happy"),
    (null, "The boy with a camera for a face", "Movie","Sad"),
    (null, "The green miles", "Movie","Sad"),
    (null, "8 Mile", "Movie","Sad"),
    (null, "The Shawshank Redemption", "Movie","Sad"),
    (null, "The Godfather", "Movie","Sad"),
    (null, "The Godfather: Part II", "Movie","Sad"),
    (null, "The Godfather: Part III", "Movie","Sad"),
    (null, "The Dark Knight", "Movie","Sad"),
    (null, "Room", "Movie","Sad"),
    (null, "Parasite", "Movie","Sad"),
    (null, "The lodge", "Movie","Neutral"),
    (null, "The good nurse", "Movie","Neutral"),
    (null, "12 angry men", "Movie","Neutral"),
    (null, "Cast away", "Movie","Neutral"),
    (null, "The Truman Show", "Movie","Neutral"),
    (null, "The Matrix", "Movie","Neutral"),
    (null, "The Matrix Reloaded", "Movie","Neutral"),
    (null, "The Matrix Revolutions", "Movie","Neutral"),
    (null, "Lilo & Stitch", "TvShow","Happy"),
    (null, "The Office", "TvShow","Happy"),
    (null, "The Witcher", "TvShow","Happy"),
    (null, "The Good Place", "TvShow","Happy"),
    (null, "Friends", "TvShow","Happy"),
    (null, "Sherlock", "TvShow","Happy"),
    (null, "The Umbrella Academy", "TvShow","Sad"),
    (null, "The Haunting of Hill House", "TvShow","Sad"),
    (null, "The Haunting of Bly Manor", "TvShow","Sad"),
    (null, "Wednesday", "TvShow","Sad"),
    (null, "Lupin", "TvShow","Sad"),
    (null, "Anne with an E", "TvShow","Sad"),
    (null, "The Crown", "TvShow","Sad"),
    (null, "The Witcher", "TvShow","Sad"),
    (null, "The Good Place", "TvShow","Sad"),
    (null, "Friends", "TvShow","Sad"),
    (null, "Defending Jacob", "TvShow","Neutral"),
    (null, "Killing Eve", "TvShow","Neutral"),
    (null, "Kaleidoscope", "TvShow","Neutral"),
    (null, "The Queens Gambit", "TvShow","Neutral"),
    (null, "The Crown", "TvShow","Neutral"),
    (null, "The Witcher", "TvShow","Neutral"),
    (null, "The Good Place", "TvShow","Neutral"),
    (null, "Friends", "TvShow","Neutral"),
    (null, "Defending Jacob", "TvShow","Neutral")
    ;

    Create Table Posts(
    id int AUTO_INCREMENT,
    msg text not null,
    username varchar(20) not null,
    unknown int default 0,
    Primary key (id),
    Foreign Key (username) References Users(username)
    
);

Insert into Posts (msg, username) values
( "Hello this is a test", "Matar");

 

Create Table Sched(
    id int AUTO_INCREMENT,
    calender varchar(30) not null,
    clock varchar(10) not null,
    user1 varchar(20) not null,
    user2 varchar(20),
    reg int default 0,
    Primary key (id),
    Foreign Key (user1) References Users(username),
    Foreign Key (user2) References Users(username)
);
    