// We now import the connection object we exported in db.js.
const db = require("../controllers/db");

// More libraries…
const express = require("express");
const bodyParser = require("body-parser");

const router = express.Router();

router.use(bodyParser.json()); // Automatically parse all POSTs as JSON.
router.use(bodyParser.urlencoded({ extended: true })); // Automatically parse URL parameters

// Skeleton for POST request
// router.post("/mypostapi", function (req, res) {
//     let sql = `
//         Your SQL Query Here
//     `;
//     db.query(sql, function (err, result) {
//         console.log("Result: " + JSON.stringify(result));
//         if (err) {
//             return res.send(err);
//         } else {
//             let returnedObject = {};
//             // Your code here
//             return res.json(returnedObject);
//         }
//     });
// });

// // Skeleton for GET Request
// router.get("/mygetapi", function (req, res) {
//     let sql = `
//         Your SQL Query Here
//     `;
//     db.query(sql, function (err, result) {
//         console.log("Result: " + JSON.stringify(result));
//         if (err) {
//             return res.send(err);
//         } else {
//             let returnedObject = {};
//             // Your code here 
//             // You can use res.json(result); to send all data as a response 
//             return res.json(returnedObject);
//         }
//     });
// });

// // ---

// // Hello World
// router.get("/health", function (req, res) {
//     return res.send("new_ok"); // For plain text, use res.send
// });

// // Basic Addition POST request
// router.post("/add", function (req, res) {
//     let body = req.body; // let is like var, but scoped
   
//     let num1 = body.num1;
//     let num2 = body.num2;

//     let result = num1 + num2;

//     return res.json({ // For JSON data, use res.json
//         "result": result
//     });
// });

// // Basic SQL GET Request
// router.get("/countrycodes", function (req, res) {
//     let sql = "Select * from Country;"

//     db.query(sql, function (err, result) {
//         console.log("Result: " + JSON.stringify(result));
//         if (err) {
//             return res.send(err);
//         } else {
//             let countriesWithTwoWords = 0;
//             for (let i = 0; i < result.length; i++) {
//                 let country = result[i];
//                 let name = country.name;
//                 let words = name.split(" ");
//                 let wordCount = words.length;
//                 if (wordCount == 2) {
//                     countriesWithTwoWords++;
//                 }
//             }
//             let myResult = {
//                 "result": result,
//                 "rows": result.length,
//                 "countriesWithTwoWords": countriesWithTwoWords
//             };
//             return res.send(myResult);
//         }
//     });
// });

// router.post("/newcountry", function(req, res) {
//     let body = req.body;
    
//     let name = body.name;
//     let code = body.code;
    
//     let sql = `
//         Insert into Country values
//             (null, "${name}", "${code}")
//         ;
//     `;
//     db.query(sql, function (err, result) {
//         console.log("Result: " + JSON.stringify(result));
//         if (err) {
//             return res.send(err);
//         } else {
//             return res.json(result);
//         }
//     });   
// });

// router.get("/test", function (req, res) {
//     let sql = "Select * from Country;"

//     db.query(sql, function (err, result) {
//         console.log("Result: " + JSON.stringify(result));
//         if (err) {
//             return res.send(err);
//         } else {
//             let countriesWithTwoWords = 0;
//             for (let i = 0; i < result.length; i++) {
//                 let country = result[i];
//                 let name = country.name;
//                 let words = name.split(" ");
//                 let wordCount = words.length;
//                 if (wordCount == 2) {
//                     countriesWithTwoWords++;
//                 }
//             }
//             let myResult = {
//                 "result": result,
//                 "rows": result.length,
//                 "countriesWithTwoWords": countriesWithTwoWords
//             };
//             return res.send(myResult);
//         }
//     });
// });

router.get("/users", function (req, res) {
    let body = req.query; // let is like var, but scoped
   
    let user = body.User;
    let pass = body.Pass;
    let sql = "Select * from Users WHERE username = ? AND pass = ?;"

    db.query(sql,[user,pass], function (err, result) {
        console.log("Result: " + JSON.stringify(result));
        if (err) {
            return res.send(err);
        } else {
            
            return res.send(result);
        }
    });
});

// router.get("/reg", function (req, res) {
//     let body = req.query; // let is like var, but scoped
   
//     let user = body.User;
//     let sql = "Select * from Users WHERE username = ?;"

//     db.query(sql,[user], function (err, result) {
//         console.log("Result: " + JSON.stringify(result));
//         if (err) {
//             console.log("err");
//             return res.send(err);
//         } else {
//             if(result.length == 0){
//                 console.log("gamed");
//                 let email = body.Email;
//                 let pass = body.Pass;
//                 let sql2 = "Insert INTO Users VALUES (?, ?, ?);"
//                 console.log("tmm1");

//                 db.query(sql2, [user, pass, email],function (err, result2){
//                     console.log("Result: " + JSON.stringify(result));
//                     if (err) {
//                         console.log("err");
//                         return res.send(err);
//                     } else {  
//                         let a = 0;
//                         console.log("tmm2");
//                     }                  
//                 } );
//                 let sql3 = "Select * from Users;"
//                 db.query(sql3,function (err, result3){
//                         if (err) {
//                             console.log("err");
//                             return res.send(err);
//                         } else {  
//                             return res.send(result3);
//                         }                      
//                 });

//             }
//             else
//             {
//                 return res.send([]);  
//             }
//         }
//     });
// });


router.get("/reg", function (req, res) {
    let body = req.query; // let is like var, but scoped
   
    let user = body.User;
    let email = body.Email;
    let pass = body.Pass;

    let sql2 = "Insert INTO Users VALUES (?, ?, ?);"
    console.log("tmm1");

    db.query(sql2, [user, pass, email],function (err, result){
        console.log("Result: " + JSON.stringify(result));
        if (err) {
            console.log("err");
            return res.send(err);
        } else {  
            console.log("tmm2");
            return res.send([1]);
        }                  
    } );
});

router.get("/checkEmail", function (req, res) {
    let body = req.query; // let is like var, but scoped
   
    let email = body.Email;
    let sql = "Select * from Users WHERE email = ?;"

    db.query(sql,[email], function (err, result) {
        if (err) {
            console.log("err");
            return res.send(err);
        } else { 
            if(result.length == 0){
                return res.send([1]);
            } 
            else{
                return res.send([0]);
            }
        }   

    });
});

router.get("/checkUser", function (req, res) {
    let body = req.query; // let is like var, but scoped
   
    let user = body.User;
    let sql = "Select * from Users WHERE username = ?;"

    db.query(sql,[user], function (err, result) {
        if (err) {
            console.log("err");
            return res.send(err);
        } else { 
            if(result.length == 0){
                return res.send([1]);
            } 
            else{
                return res.send([0]);
            }
        }   

    });
});

router.get("/getEvents", function (req, res) {
    let sql = "Select * from Events;"

    db.query(sql,function (err, result) {
        console.log("Result: " + JSON.stringify(result));
        if (err) {
            return res.send(err);
        } else {
            
            return res.send(result);
        }
    });
});

router.get("/getMovShows", function (req, res) {

    let body = req.query; // let is like var, but scoped
   
    let type = body.type;
    let mood = body.mood;

    let sql = "Select * from MovShows Where MovShows_type = ? AND MovShows_mood = ?;"

    db.query(sql,[type,mood],function (err, result) {
        console.log("Result: " + JSON.stringify(result));
        if (err) {
            return res.send(err);
        } else {
            
            return res.send(result);
        }
    });
});

router.get("/setMovShows", function (req, res) {
    let body = req.query; // let is like var, but scoped
   
    let name = body.name;
    let type = body.type;
    let mood = body.mood;

    let sql = "Insert INTO MovShows VALUES (null,?, ?, ?);"

    db.query(sql, [name, type, mood],function (err, result){
        console.log("Result: " + JSON.stringify(result));
        if (err) {
            console.log("err");
            return res.send(err);
        } else {  
            console.log("tmm2");
            return res.send([1]);
        }                  
    } );
});

router.get("/addPost", function (req, res) {
    let body = req.query; 
   
    let user = body.User;
    let msg = body.Msg;
    let an = body.An;
    let sql = "Insert INTO Posts (msg, username, unknown) VALUES (?, ?,?);"

    db.query(sql,[msg, user, an], function (err, result) {
        if (err) {
            console.log("err");
            return res.send(err);
        } else { 
            return res.send([]);
        }   

    });
});

router.get("/getPosts", function (req, res) {
    let sql = "Select * from Posts Order by id Desc;"

    db.query(sql, function (err, result) {
        if (err) {
            console.log("err");
            return res.send(err);
        } else { 
            return res.send(result);
        }   

    });
});


///////////////////////////////////////////////////////

// Sched data


router.get("/addSched", function (req, res) {
    let body = req.query; 
   
    let user1 = body.User1;
    let cal = body.Cal;
    let time = body.Time;
    let sql = "Insert INTO Sched (user1, calender, clock ) VALUES (?, ?,?);"

    db.query(sql,[user1, cal, time], function (err, result) {
        if (err) {
            console.log("err");
            return res.send(err);
        } else { 
            return res.send([]);
        }   

    });
});


router.get("/selectSched", function (req, res) {
    let body = req.query; 
   
    let user1 = body.User1;
    let user2 = body.User2;
    let cal = body.Cal;
    let time = body.Time;
    console.log(user1);
    console.log(user2);
    console.log(cal);
    console.log(time);
    let sql = "Update Sched Set user2 = ?, reg = 1 Where user1 = ? AND calender = ? AND clock = ?"

    db.query(sql,[user2, user1, cal, time], function (err, result) {
        if (err) {
            console.log("err");
            return res.send(err);
        } else { 
            return res.send([]);
        }   

    });
});



router.get("/delSched", function (req, res) {
    let body = req.query; 
   
    let user1 = body.User1;
    let user2 = body.User2;
    let cal = body.Cal;
    let time = body.Time;
    console.log(user1);
    console.log(user2);
    console.log(cal);
    console.log(time);
    // let sql = "Update Sched Set user2 = ?, reg = 1 Where user1 = ? AND calender = ? AND clock = ?"
    let sql = "Delete from Sched Where user2 = ? AND user1 = ? AND calender = ? AND clock = ?"

    db.query(sql,[user2, user1, cal, time], function (err, result) {
        if (err) {
            console.log("err");
            return res.send(err);
        } else { 
            return res.send([]);
        }   

    });
});






router.get("/getSched", function (req, res) {
    let body = req.query; 
   
    let user1 = body.User1;
    let cal = body.Cal;
    let time = body.Time;
    let sql = "Select * from Sched"

    db.query(sql,[user1, cal, time], function (err, result) {
        if (err) {
            console.log("err");
            return res.send(err);
        } else { 
            return res.send(result);
        }   

    });
});

// Export the created router
module.exports = router;